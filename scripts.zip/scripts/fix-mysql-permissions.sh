#!/bin/bash
# 修復 MySQL 用戶權限腳本

echo "等待 MySQL 準備就緒..."
sleep 10

echo "修復 springboot 用戶權限..."
kubectl exec deployment/mysql -- mysql -uroot -prootpassword << 'EOF'
-- 刪除舊的 springboot 用戶（如果存在）
DROP USER IF EXISTS 'springboot'@'localhost';
DROP USER IF EXISTS 'springboot'@'%';

-- 創建新的 springboot 用戶，允許從任何主機訪問
CREATE USER 'springboot'@'%' IDENTIFIED BY 'springboot123';

-- 授予完整權限
GRANT ALL PRIVILEGES ON spring_boot_demo.* TO 'springboot'@'%';

-- 刷新權限
FLUSH PRIVILEGES;

-- 驗證用戶
SELECT User, Host FROM mysql.user WHERE User='springboot';
EOF

echo "權限修復完成！"
echo ""
echo "重啟失敗的 App Pods..."
kubectl delete pod -l io.kompose.service=app --field-selector=status.phase!=Running

echo "完成！"
