#!/bin/bash

# Docker 安裝腳本
set -e

echo "================================"
echo "開始安裝 Docker..."
echo "================================"

# 更新系統套件
sudo apt-get update

# 安裝必要套件
sudo apt-get install -y \
    apt-transport-https \
    ca-certificates \
    curl \
    gnupg \
    lsb-release

# 新增 Docker 官方 GPG key
# 使用 --yes --batch 避免與現有檔案衝突時詢問
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor --yes --batch -o /usr/share/keyrings/docker-archive-keyring.gpg

# 設定 Docker repository
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# 安裝 Docker Engine
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io

# 配置 containerd
sudo mkdir -p /etc/containerd
containerd config default | sudo tee /etc/containerd/config.toml

# 設置 systemd cgroup driver
sudo sed -i 's/SystemdCgroup = false/SystemdCgroup = true/g' /etc/containerd/config.toml

# 重啟 containerd
sudo systemctl enable containerd
sudo systemctl restart containerd
sudo systemctl status containerd --no-pager

# 設定 Docker 使用 systemd cgroup driver
sudo mkdir -p /etc/docker
cat <<EOF | sudo tee /etc/docker/daemon.json
{
  "exec-opts": ["native.cgroupdriver=systemd"],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m"
  },
  "storage-driver": "overlay2"
}
EOF

# 重啟 Docker
sudo systemctl enable docker
sudo systemctl daemon-reload
sudo systemctl restart docker

# 將 vagrant 用戶加入 docker 群組
sudo usermod -aG docker vagrant

# 驗證 Docker 安裝
sudo docker --version
sudo docker run hello-world

echo "================================"
echo "Docker 安裝完成！"
echo "================================"