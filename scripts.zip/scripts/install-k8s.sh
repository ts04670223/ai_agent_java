#!/bin/bash

# Kubernetes 安裝腳本
set -e

echo "================================"
echo "開始安裝 Kubernetes..."
echo "================================"

# 關閉 swap (Kubernetes 需求)
sudo swapoff -a
sudo sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab

# 載入必要的內核模組
cat <<EOF | sudo tee /etc/modules-load.d/k8s.conf
overlay
br_netfilter
EOF

# 立即載入模組
sudo modprobe overlay
sudo modprobe br_netfilter

# 驗證模組已載入
lsmod | grep br_netfilter
lsmod | grep overlay

# 設定必要的 sysctl 參數
cat <<EOF | sudo tee /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-iptables  = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.ipv4.ip_forward                 = 1
EOF

sudo sysctl --system

# 安裝 Kubernetes 套件
sudo apt-get update
sudo apt-get install -y apt-transport-https ca-certificates curl

# 新增 Kubernetes GPG key
# 使用 --yes --batch 避免與現有檔案衝突時詢問
curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.28/deb/Release.key | sudo gpg --dearmor --yes --batch -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg

# 新增 Kubernetes repository
echo 'deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.28/deb/ /' | sudo tee /etc/apt/sources.list.d/kubernetes.list

# 安裝 kubelet, kubeadm, kubectl
sudo apt-get update
sudo apt-get install -y kubelet kubeadm kubectl
sudo apt-mark hold kubelet kubeadm kubectl

# 啟用 kubelet
sudo systemctl enable kubelet

echo "================================"
echo "Kubernetes 套件安裝完成！"
echo "版本資訊："
kubectl version --client
kubeadm version
echo "================================"