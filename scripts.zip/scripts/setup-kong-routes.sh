#!/bin/bash

echo "========================================"
echo "配置 Kong Gateway 路由"
echo "========================================"

# Kong Admin API 地址
KONG_ADMIN="http://192.168.10.10:30003"

# 顏色定義
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo ""
echo "1. 檢查 Kong 狀態..."
if ! curl -s -f "${KONG_ADMIN}" > /dev/null; then
    echo -e "${RED}✗ Kong Admin API 無法連線${NC}"
    echo "請確認 Kong 是否正在運行: kubectl get pods | grep kong"
    exit 1
fi
echo -e "${GREEN}✓ Kong Admin API 正常${NC}"

echo ""
echo "2. 清除現有配置..."
# 刪除現有 routes
for route_id in $(curl -s "${KONG_ADMIN}/routes" | grep -o '"id":"[^"]*"' | cut -d'"' -f4); do
    echo "  刪除 route: $route_id"
    curl -s -X DELETE "${KONG_ADMIN}/routes/${route_id}"
done

# 刪除現有 services
for service_id in $(curl -s "${KONG_ADMIN}/services" | grep -o '"id":"[^"]*"' | cut -d'"' -f4); do
    echo "  刪除 service: $service_id"
    curl -s -X DELETE "${KONG_ADMIN}/services/${service_id}"
done

echo ""
echo "3. 創建 app-service (Spring Boot 應用)..."
SERVICE_RESPONSE=$(curl -s -X POST "${KONG_ADMIN}/services" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "app-service",
    "url": "http://app:8080"
  }')

SERVICE_ID=$(echo "$SERVICE_RESPONSE" | grep -o '"id":"[^"]*"' | head -1 | cut -d'"' -f4)

if [ -n "$SERVICE_ID" ]; then
    echo -e "${GREEN}✓ Service 創建成功: $SERVICE_ID${NC}"
else
    echo -e "${RED}✗ Service 創建失敗${NC}"
    echo "$SERVICE_RESPONSE"
    exit 1
fi

echo ""
echo "4. 創建 API 路由..."
ROUTE_RESPONSE=$(curl -s -X POST "${KONG_ADMIN}/services/app-service/routes" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-route",
    "paths": ["/api"],
    "strip_path": false,
    "preserve_host": false
  }')

ROUTE_ID=$(echo "$ROUTE_RESPONSE" | grep -o '"id":"[^"]*"' | head -1 | cut -d'"' -f4)

if [ -n "$ROUTE_ID" ]; then
    echo -e "${GREEN}✓ Route 創建成功: $ROUTE_ID${NC}"
else
    echo -e "${RED}✗ Route 創建失敗${NC}"
    echo "$ROUTE_RESPONSE"
    exit 1
fi

echo ""
echo "5. 啟用 CORS 插件..."
CORS_RESPONSE=$(curl -s -X POST "${KONG_ADMIN}/services/app-service/plugins" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "cors",
    "config": {
      "origins": ["*"],
      "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
      "headers": ["Accept", "Accept-Version", "Content-Length", "Content-MD5", "Content-Type", "Date", "X-Auth-Token", "Authorization"],
      "exposed_headers": ["X-Auth-Token"],
      "credentials": true,
      "max_age": 3600
    }
  }')

if echo "$CORS_RESPONSE" | grep -q '"name":"cors"'; then
    echo -e "${GREEN}✓ CORS 插件啟用成功${NC}"
else
    echo -e "${YELLOW}⚠ CORS 插件可能已存在或啟用失敗${NC}"
fi

echo ""
echo "========================================"
echo "配置完成！"
echo "========================================"
echo ""
echo "當前配置："
echo "  Service: app-service → http://app:8080"
echo "  Route: /api → app-service"
echo "  Plugin: CORS (已啟用)"
echo ""
echo "測試指令："
echo "  curl -H \"Host: test6.test\" http://192.168.10.10:30000/api/products"
echo "  curl -H \"Host: test6.test\" http://192.168.10.10:30000/api/cart/1"
echo ""
echo "完整測試（透過 Nginx）："
echo "  curl http://192.168.10.10/api/products"
echo "  curl http://192.168.10.10/api/cart/1"
echo ""

# 顯示當前配置
echo "驗證配置："
echo "Services:"
curl -s "${KONG_ADMIN}/services" | grep -o '"name":"[^"]*"' | cut -d'"' -f4 | while read -r name; do
    echo "  → $name"
done

echo ""
echo "Routes:"
curl -s "${KONG_ADMIN}/routes" | grep -o '"name":"[^"]*"' | cut -d'"' -f4 | while read -r name; do
    echo "  → $name"
done

echo ""
