#!/bin/bash

# 更新 Nginx 配置，添加 Prometheus 和 Grafana 路由
echo "================================"
echo "更新 Nginx 配置 - 添加監控路由"
echo "================================"

# 備份原配置
sudo cp /etc/nginx/sites-available/test6.test /etc/nginx/sites-available/test6.test.backup.$(date +%Y%m%d_%H%M%S)

# 創建新配置
cat <<'EOF' | sudo tee /etc/nginx/sites-available/test6.test
server {
    listen 80;
    server_name test6.test;

    # 前端應用
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # 後端 API 透過 Kong Gateway
    location /api {
        proxy_pass http://192.168.10.10:30000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Prometheus 監控 (透過 Kong Gateway)
    location /prometheus {
        proxy_pass http://192.168.10.10:30000/prometheus;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Grafana 監控 (透過 Kong Gateway)
    location /grafana {
        proxy_pass http://192.168.10.10:30000/grafana;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Grafana WebSocket 支持
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
EOF

echo ""
echo "測試 Nginx 配置..."
if sudo nginx -t; then
    echo ""
    echo "✅ Nginx 配置有效，重新載入..."
    sudo systemctl reload nginx
    echo ""
    echo "================================"
    echo "✅ 配置更新完成！"
    echo "================================"
    echo ""
    echo "現在可以通過以下 URL 訪問："
    echo "  前端:       http://test6.test/"
    echo "  後端 API:   http://test6.test/api"
    echo "  Prometheus: http://test6.test/prometheus"
    echo "  Grafana:    http://test6.test/grafana"
    echo ""
else
    echo ""
    echo "❌ Nginx 配置錯誤，恢復備份..."
    sudo cp /etc/nginx/sites-available/test6.test.backup.* /etc/nginx/sites-available/test6.test
    sudo systemctl reload nginx
    exit 1
fi
