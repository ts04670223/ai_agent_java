#!/bin/bash
# 更新 Nginx 配置以整合 Kong

echo "更新 Nginx 配置以整合 Kong Gateway..."

cat > /tmp/test6-nginx.conf << 'NGXEOF'
server {
    listen 80;
    server_name test6.test;

    # 前端應用
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # 後端 API 透過 Kong Gateway
    location /api {
        proxy_pass http://192.168.10.10:30000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
NGXEOF

sudo mv /tmp/test6-nginx.conf /etc/nginx/sites-available/test6.test

echo "測試 Nginx 配置..."
sudo nginx -t

if [ $? -eq 0 ]; then
    echo "重新載入 Nginx..."
    sudo systemctl reload nginx
    echo "✓ Nginx 配置更新完成！"
    echo ""
    echo "測試指令："
    echo "  curl -I http://192.168.10.10/api"
    echo ""
    echo "架構："
    echo "  http://test6.test/     → Nginx → Vite (port 3000)"
    echo "  http://test6.test/api  → Nginx → Kong (port 30000) → Spring Boot"
else
    echo "✗ Nginx 配置有誤，請檢查"
    exit 1
fi
