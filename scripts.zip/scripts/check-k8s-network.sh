#!/bin/bash

# Kubernetes 網絡診斷腳本

echo "================================"
echo "Kubernetes 網絡診斷報告"
echo "================================"
echo ""

# 1. 檢查 Flannel 狀態
echo "1. Flannel Pods 狀態:"
echo "---"
kubectl get pods -n kube-flannel -o wide
echo ""

# 2. 檢查 Flannel 日誌
echo "2. Flannel 最近日誌:"
echo "---"
FLANNEL_POD=$(kubectl get pods -n kube-flannel -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
if [ -n "$FLANNEL_POD" ]; then
    kubectl logs -n kube-flannel "$FLANNEL_POD" --tail=20
else
    echo "找不到 Flannel pod"
fi
echo ""

# 3. 檢查 subnet.env 文件
echo "3. Flannel subnet.env 文件:"
echo "---"
if [ -f /run/flannel/subnet.env ]; then
    cat /run/flannel/subnet.env
else
    echo "⚠ 文件不存在: /run/flannel/subnet.env"
fi
echo ""

# 4. 檢查 CNI 配置
echo "4. CNI 配置文件:"
echo "---"
ls -la /etc/cni/net.d/ 2>/dev/null || echo "CNI 目錄不存在或為空"
echo ""

# 5. 檢查節點狀態
echo "5. 節點狀態:"
echo "---"
kubectl get nodes -o wide
echo ""

# 6. 檢查 App Pods 狀態
echo "6. App Pods 狀態:"
echo "---"
kubectl get pods -l io.kompose.service=app -o wide
echo ""

# 7. 檢查失敗的 Pods 詳情
echo "7. 失敗的 App Pods 詳情:"
echo "---"
FAILED_PODS=$(kubectl get pods -l io.kompose.service=app --field-selector=status.phase!=Running -o jsonpath='{.items[*].metadata.name}' 2>/dev/null)
if [ -n "$FAILED_PODS" ]; then
    for pod in $FAILED_PODS; do
        echo "Pod: $pod"
        echo "Events:"
        kubectl describe pod "$pod" | grep -A 10 "Events:"
        echo ""
    done
else
    echo "沒有失敗的 app pods"
fi

# 8. 檢查系統參數
echo "8. 系統網絡參數:"
echo "---"
echo "net.bridge.bridge-nf-call-iptables = $(sysctl net.bridge.bridge-nf-call-iptables | awk '{print $3}')"
echo "net.ipv4.ip_forward = $(sysctl net.ipv4.ip_forward | awk '{print $3}')"
echo ""

# 9. 檢查 iptables
echo "9. iptables 規則統計:"
echo "---"
sudo iptables -t nat -L -n | head -20
echo ""

echo "================================"
echo "診斷完成"
echo "================================"
