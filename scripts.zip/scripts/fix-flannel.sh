#!/bin/bash

# Flannel 網絡插件修復腳本
set -e

echo "================================"
echo "開始修復 Flannel 網絡插件..."
echo "================================"

# 1. 刪除現有的 Flannel
echo "步驟 1: 刪除現有的 Flannel 配置..."
kubectl delete -f https://github.com/flannel-io/flannel/releases/latest/download/kube-flannel.yml --ignore-not-found=true

# 2. 清理 CNI 配置
echo "步驟 2: 清理 CNI 配置..."
sudo rm -rf /etc/cni/net.d/*
sudo rm -rf /var/lib/cni/
sudo rm -rf /run/flannel/

# 3. 重啟 containerd
echo "步驟 3: 重啟 containerd..."
sudo systemctl restart containerd
sleep 5

# 4. 確保系統參數正確
echo "步驟 4: 設置系統參數..."
sudo modprobe br_netfilter
sudo sysctl -w net.bridge.bridge-nf-call-iptables=1
sudo sysctl -w net.ipv4.ip_forward=1

# 5. 重新安裝 Flannel
echo "步驟 5: 重新安裝 Flannel..."
kubectl apply -f https://github.com/flannel-io/flannel/releases/latest/download/kube-flannel.yml

# 6. 等待 Flannel pods 啟動
echo "步驟 6: 等待 Flannel pods 啟動..."
echo "這可能需要 1-2 分鐘..."
sleep 10

for i in {1..30}; do
    FLANNEL_STATUS=$(kubectl get pods -n kube-flannel -o jsonpath='{.items[*].status.phase}' 2>/dev/null || echo "")
    if echo "$FLANNEL_STATUS" | grep -q "Running"; then
        echo "✓ Flannel pods 正在運行"
        break
    fi
    echo "等待 Flannel pods 啟動... ($i/30)"
    sleep 5
done

# 7. 檢查 flannel subnet.env 文件
echo "步驟 7: 檢查 Flannel 配置文件..."
if [ -f /run/flannel/subnet.env ]; then
    echo "✓ Flannel subnet.env 文件已創建"
    cat /run/flannel/subnet.env
else
    echo "⚠ Flannel subnet.env 文件尚未創建，請等待..."
fi

# 8. 刪除失敗的 pods
echo "步驟 8: 刪除失敗的 app pods..."
kubectl delete pods -l io.kompose.service=app --grace-period=0 --force 2>/dev/null || true

# 9. 顯示當前狀態
echo ""
echo "================================"
echo "修復完成！當前狀態："
echo "================================"
echo ""
echo "Flannel Pods 狀態:"
kubectl get pods -n kube-flannel -o wide
echo ""
echo "App Pods 狀態:"
kubectl get pods -l io.kompose.service=app -o wide
echo ""
echo "所有 Pods 狀態:"
kubectl get pods --all-namespaces | grep -E "(flannel|app)"
echo ""
echo "================================"
echo "如果 app pod 仍然失敗，請執行："
echo "kubectl describe pod <pod-name>"
echo "kubectl logs <pod-name>"
echo "================================"
