#!/bin/bash

# 前端自動化設定腳本
set -e

echo "================================"
echo "開始設定前端環境..."
echo "================================"

# 1. 安裝 Node.js (v24)
CURRENT_NODE_VER=$(node -v 2>/dev/null || echo "none")
REQUIRED_PREFIX="v24"

if [[ "$CURRENT_NODE_VER" != $REQUIRED_PREFIX* ]]; then
    echo "安裝 Node.js v24..."
    # 移除舊版以免衝突
    sudo apt-get remove -y nodejs npm || true
    sudo apt-get autoremove -y || true

    # 使用 NodeSource 安裝 v24
    curl -fsSL https://deb.nodesource.com/setup_24.x | sudo -E bash -
    sudo apt-get install -y nodejs
else
    echo "Node.js 已安裝: $(node -v)"
fi

# 安裝全域 Vite 避免因為 no-bin-links 導致找不到指令
echo "安裝全域 Vite..."
sudo npm install -g vite

# 2. 安裝專案依賴
echo "安裝前端依賴..."

cd /vagrant/frontend
# 清理 logic: 只有在看起來損壞時才清理，避免每次都重裝 (耗時)
if [ -d "node_modules" ] && [ ! -d "node_modules/vite" ]; then
    echo "node_modules 不完整，清理重裝..."
    rm -rf node_modules
fi

# 安裝依賴 (包含 devDependencies 確保 vite 可用)
sudo -u vagrant npm install --no-bin-links

# 3. 安裝 Nginx 作為反向代理 (讓 test6.test 能用 port 80 訪問 port 3000)
echo "安裝與設定 Nginx..."
sudo apt-get install -y nginx

# 配置 Nginx 虛擬主機 (整合 Kong Gateway)
cat <<EOF | sudo tee /etc/nginx/sites-available/test6.test
server {
    listen 80;
    server_name test6.test;

    # 前端應用
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }

    # 後端 API 透過 Kong Gateway
    location /api {
        proxy_pass http://192.168.10.10:30000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

# 啟用站點
sudo ln -sf /etc/nginx/sites-available/test6.test /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl restart nginx

# 4. 設定 Systemd 服務自動啟動前端
echo "設定前端 Systemd 服務..."

cat <<EOF | sudo tee /etc/systemd/system/frontend.service
[Unit]
Description=Frontend React App
After=network.target

[Service]
Type=simple
User=vagrant
WorkingDirectory=/vagrant/frontend
# 使用 host 0.0.0.0 確保能被 Nginx 轉發 (雖然 localhost 也可以)
ExecStart=/usr/bin/npm run dev -- --host
Restart=always
RestartSec=10
Environment=PATH=/usr/bin:/usr/local/bin
Environment=NODE_ENV=development

[Install]
WantedBy=multi-user.target
EOF

# 啟用並啟動服務
sudo systemctl daemon-reload
sudo systemctl enable frontend.service
sudo systemctl restart frontend.service

echo "================================"
echo "前端環境設定完成！"
echo "URL: http://test6.test (需在主機設定 hosts)"
echo "     http://192.168.10.10"
echo "================================"
