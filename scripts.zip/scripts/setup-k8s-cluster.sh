#!/bin/bash

# Kubernetes 叢集設定腳本
set -e

echo "================================"
echo "開始設定 Kubernetes 叢集..."
echo "================================"

# 確保 containerd 正在運行
echo "檢查 containerd 狀態..."
sudo systemctl enable containerd
sudo systemctl restart containerd
sudo systemctl status containerd --no-pager || true

# 確保內核模組已載入
echo "載入內核模組..."
sudo modprobe overlay
sudo modprobe br_netfilter

# 應用 sysctl 參數
sudo sysctl --system

# 驗證前置條件
echo "驗證 containerd..."
sudo crictl --runtime-endpoint unix:///var/run/containerd/containerd.sock version || true

echo "等待服務就緒..."
sleep 5

MASTER_IP="192.168.10.10"

# 檢查是否需要因 IP 變更而重置
if [ -f /etc/kubernetes/admin.conf ]; then
    if ! grep -q "$MASTER_IP" /etc/kubernetes/admin.conf; then
        echo "偵測到 IP 變更 (設定檔與 $MASTER_IP 不符)，執行 kubeadm reset..."
        sudo kubeadm reset -f
        sudo rm -f /etc/kubernetes/admin.conf
        sudo rm -f /home/vagrant/.kube/config
        sudo rm -rf /etc/cni/net.d
        sudo rm -rf /var/lib/cni/
        sudo rm -rf /run/flannel/
        
        # Reset 可能導致 containerd 不穩定，重啟並等待
        echo "重啟 containerd..."
        sudo systemctl restart containerd
        sleep 5
    fi
fi

# 確保 containerd 正常回應
echo "等待 Container Runtime 就緒..."
for i in {1..10}; do
    if sudo crictl --runtime-endpoint unix:///var/run/containerd/containerd.sock version &> /dev/null; then
        break
    fi
    echo "Container Runtime 尚未就緒，重試中..."
    sleep 3
done

# 初始化 Kubernetes 叢集
if [ ! -f /etc/kubernetes/admin.conf ]; then
    echo "初始化 Kubernetes Master ($MASTER_IP)..."
    sudo kubeadm init \
      --apiserver-advertise-address=$MASTER_IP \
      --pod-network-cidr=10.244.0.0/16 \
      --node-name k8s-master
else
    echo "Kubernetes 已經初始化，跳過 init..."
fi

# 設定 kubectl 給 vagrant 用戶使用
mkdir -p /home/vagrant/.kube
if [ -f /etc/kubernetes/admin.conf ]; then
    sudo cp -f /etc/kubernetes/admin.conf /home/vagrant/.kube/config
    sudo chown vagrant:vagrant /home/vagrant/.kube/config
fi

# 設定給 root 用戶使用
export KUBECONFIG=/etc/kubernetes/admin.conf
echo "export KUBECONFIG=/etc/kubernetes/admin.conf" >> /root/.bashrc

# 設定給 vagrant 用戶使用
# 避免重複添加
if ! grep -q "KUBECONFIG" /home/vagrant/.bashrc; then
    echo "export KUBECONFIG=/home/vagrant/.kube/config" >> /home/vagrant/.bashrc
fi

# 等待 API Server 就緒
echo "等待 Kubernetes API Server 就緒..."
MAX_RETRIES=60
for i in $(seq 1 $MAX_RETRIES); do
    if kubectl get nodes --request-timeout=2s &> /dev/null; then
        echo "API Server 已就緒！"
        break
    fi
    echo "等待 API Server 啟動中 ... ($i/$MAX_RETRIES)"
    sleep 5
done

# 允許在 master 節點上調度 pods (單節點叢集)
kubectl taint nodes --all node-role.kubernetes.io/control-plane- || true

# 安裝 Flannel 網路插件
echo "安裝 Flannel 網路插件..."
# 清理可能存在的舊配置
sudo rm -rf /var/lib/cni/
sudo rm -rf /run/flannel/
sudo mkdir -p /run/flannel/

kubectl apply -f https://github.com/flannel-io/flannel/releases/latest/download/kube-flannel.yml

# 等待 Flannel Pods 就緒
echo "等待 Flannel Pods 就緒..."
MAX_FLANNEL_RETRIES=60
FLANNEL_READY=false
for i in $(seq 1 $MAX_FLANNEL_RETRIES); do
    if kubectl get pods -n kube-flannel | grep -q "Running"; then
        echo "Flannel Pod 已在運行！"
        FLANNEL_READY=true
        break
    fi
    echo "等待 Flannel 啟動中 ... ($i/$MAX_FLANNEL_RETRIES)"
    sleep 2
done

# 如果 Flannel Pods 運行了，等待 subnet.env 生成
if [ "$FLANNEL_READY" = true ]; then
    echo "等待 Flannel 生成網絡配置 (subnet.env)..."
    for i in {1..30}; do
        if [ -f /run/flannel/subnet.env ]; then
            echo "✓ Flannel 網絡配置已就緒！"
            break
        fi
        echo "等待 subnet.env 文件生成... ($i/30)"
        sleep 2
    done

    # 再次檢查，如果仍然沒有，嘗試重啟 containerd 觸發 CNI 初始化
    if [ ! -f /run/flannel/subnet.env ]; then
        echo "警告：subnet.env 尚未生成，嘗試重啟 containerd..."
        sudo systemctl restart containerd
        sleep 5
    fi
else
    echo "警告：Flannel Pod 啟動超時，請檢查日誌"
fi

# 等待所有系統 pods 啟動
echo "等待 Kubernetes 系統組件啟動..."
sleep 10

# 安裝 Kubernetes Dashboard (選用)
kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.7.0/aio/deploy/recommended.yaml

# 創建 Dashboard 管理員用戶
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: ServiceAccount
metadata:
  name: admin-user
  namespace: kubernetes-dashboard
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: admin-user
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
- kind: ServiceAccount
  name: admin-user
  namespace: kubernetes-dashboard
EOF

# 顯示叢集狀態
echo "================================"
echo "Kubernetes 叢集設定完成！"
echo "================================"
kubectl get nodes
kubectl get pods -A

echo ""
echo "================================"
echo "Dashboard 存取方式："
echo "1. 在 VM 內執行: kubectl proxy --address='0.0.0.0' --accept-hosts='.*'"
echo "2. 瀏覽器開啟: http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/"
echo ""
echo "取得 Dashboard Token:"
kubectl -n kubernetes-dashboard create token admin-user
echo "================================"