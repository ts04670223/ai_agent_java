#!/bin/bash

# Kubernetes 重啟問題一鍵修復腳本
# 用於在 VM 重啟後快速恢復所有服務

set -e

echo "╔════════════════════════════════════════════════╗"
echo "║  Kubernetes 重啟問題自動修復工具              ║"
echo "╚════════════════════════════════════════════════╝"
echo ""

# 顏色定義
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 步驟 1: 檢查 Flannel 狀態
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${YELLOW}步驟 1: 檢查 Flannel 網絡插件${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

FLANNEL_STATUS=$(kubectl get pods -n kube-flannel -o jsonpath='{.items[*].status.phase}' 2>/dev/null || echo "NotFound")

if echo "$FLANNEL_STATUS" | grep -q "Running"; then
    echo -e "${GREEN}✓${NC} Flannel 正在運行"
else
    echo -e "${YELLOW}⚠${NC} Flannel 未就緒，等待啟動..."
    kubectl wait --for=condition=ready pod -l app=flannel -n kube-flannel --timeout=300s || {
        echo -e "${RED}✗${NC} Flannel 啟動超時"
        echo "嘗試重新安裝 Flannel..."
        kubectl delete -f https://github.com/flannel-io/flannel/releases/latest/download/kube-flannel.yml --ignore-not-found=true
        sleep 5
        kubectl apply -f https://github.com/flannel-io/flannel/releases/latest/download/kube-flannel.yml
        kubectl wait --for=condition=ready pod -l app=flannel -n kube-flannel --timeout=300s
    }
fi

# 驗證 subnet.env
if [ -f /run/flannel/subnet.env ]; then
    echo -e "${GREEN}✓${NC} subnet.env 文件存在"
else
    echo -e "${YELLOW}⚠${NC} subnet.env 文件缺失，等待 Flannel 創建..."
    sleep 30
fi

# 步驟 2: 清理失敗的 Pods
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${YELLOW}步驟 2: 清理失敗的 Pods${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

FAILED_PODS=$(kubectl get pods --all-namespaces --field-selector=status.phase=Failed -o name 2>/dev/null | wc -l)
UNKNOWN_PODS=$(kubectl get pods --all-namespaces --field-selector=status.phase=Unknown -o name 2>/dev/null | wc -l)

if [ "$FAILED_PODS" -gt "0" ] || [ "$UNKNOWN_PODS" -gt "0" ]; then
    echo "發現 $FAILED_PODS 個 Failed pods 和 $UNKNOWN_PODS 個 Unknown pods"
    kubectl delete pods --field-selector=status.phase=Failed --all-namespaces --grace-period=0 --force 2>/dev/null || true
    kubectl delete pods --field-selector=status.phase=Unknown --all-namespaces --grace-period=0 --force 2>/dev/null || true
    echo -e "${GREEN}✓${NC} 已清理失敗的 pods"
else
    echo -e "${GREEN}✓${NC} 沒有失敗的 pods"
fi

# 步驟 3: 修復 Kong 資料庫
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${YELLOW}步驟 3: 檢查並修復 Kong 資料庫${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 等待 PostgreSQL 就緒
kubectl wait --for=condition=ready pod -l io.kompose.service=kong-database --timeout=300s || {
    echo -e "${RED}✗${NC} Kong 資料庫未就緒"
    exit 1
}

# 檢查 migrations job 狀態
MIGRATION_STATUS=$(kubectl get jobs kong-migrations -o jsonpath='{.status.succeeded}' 2>/dev/null || echo "0")

if [ "$MIGRATION_STATUS" == "1" ]; then
    echo -e "${GREEN}✓${NC} Kong migrations 已完成"
else
    echo -e "${YELLOW}⚠${NC} 重新執行 Kong migrations..."
    kubectl delete job kong-migrations --ignore-not-found=true
    sleep 3
    kubectl apply -f /vagrant/kong/kong-k8s.yaml
    kubectl wait --for=condition=complete job/kong-migrations --timeout=300s
    echo -e "${GREEN}✓${NC} Kong migrations 完成"
fi

# 步驟 4: 重啟並等待 Kong
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${YELLOW}步驟 4: 重啟 Kong 服務${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 檢查 Kong pod 狀態
KONG_STATUS=$(kubectl get pods -l io.kompose.service=kong -o jsonpath='{.items[*].status.phase}' 2>/dev/null || echo "NotFound")

if echo "$KONG_STATUS" | grep -q "Running"; then
    echo -e "${GREEN}✓${NC} Kong 正在運行"
else
    echo -e "${YELLOW}⚠${NC} Kong 未運行，重啟中..."
    kubectl delete pod -l io.kompose.service=kong --grace-period=0 --force 2>/dev/null || true
    sleep 5
    kubectl apply -f /vagrant/kong/kong-k8s.yaml
fi

# 等待 Kong 就緒
echo "等待 Kong 啟動..."
kubectl wait --for=condition=ready pod -l io.kompose.service=kong --timeout=300s || {
    echo -e "${RED}✗${NC} Kong 啟動失敗"
    kubectl logs -l io.kompose.service=kong --tail=50
    exit 1
}

echo -e "${GREEN}✓${NC} Kong 已就緒"

# 步驟 5: 配置 Kong 路由
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${YELLOW}步驟 5: 配置 Kong 路由${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 等待 Kong Admin API 就緒
echo "等待 Kong Admin API..."
for i in {1..30}; do
    if curl -f -s http://192.168.10.10:8003/ > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC} Kong Admin API 可用"
        break
    fi
    sleep 2
done

# 檢查路由是否存在
ROUTES_COUNT=$(curl -s http://192.168.10.10:8003/routes 2>/dev/null | grep -o '"name"' | wc -l)

if [ "$ROUTES_COUNT" -gt "0" ]; then
    echo -e "${GREEN}✓${NC} Kong 路由已配置 ($ROUTES_COUNT 個)"
else
    echo -e "${YELLOW}⚠${NC} Kong 路由未配置，執行配置腳本..."
    bash /vagrant/kong/setup-routes.sh
    echo -e "${GREEN}✓${NC} Kong 路由配置完成"
fi

# 步驟 6: 檢查並修復 App Pods
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${YELLOW}步驟 6: 檢查 App Pods 狀態${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

APP_RUNNING=$(kubectl get pods -l io.kompose.service=app -o jsonpath='{.items[*].status.phase}' | grep -o "Running" | wc -l)
APP_TOTAL=$(kubectl get pods -l io.kompose.service=app --no-headers | wc -l)

echo "App Pods: $APP_RUNNING/$APP_TOTAL 正在運行"

if [ "$APP_RUNNING" -eq "0" ]; then
    echo -e "${RED}✗${NC} 所有 App pods 都未運行，重啟部署..."
    kubectl rollout restart deployment/app
fi

# 等待至少一個 App pod 就緒
echo "等待 App pods 啟動..."
kubectl wait --for=condition=ready pod -l io.kompose.service=app --timeout=600s || {
    echo -e "${YELLOW}⚠${NC} 部分 App pods 可能尚未就緒（啟動時間較長）"
}

READY_COUNT=$(kubectl get pods -l io.kompose.service=app -o jsonpath='{.items[*].status.containerStatuses[0].ready}' | grep -o "true" | wc -l)
echo -e "${GREEN}✓${NC} $READY_COUNT 個 App pods 已就緒"

# 步驟 7: 驗證服務
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${YELLOW}步驟 7: 驗證服務${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

sleep 5

# 測試 API
echo -n "測試 API 端點... "
if curl -f -s http://192.168.10.10:30000/api/products > /dev/null 2>&1; then
    echo -e "${GREEN}✓${NC}"
else
    echo -e "${RED}✗${NC}"
    echo "API 測試失敗，檢查詳細信息："
    curl -v http://192.168.10.10:30000/api/products
fi

# 最終報告
echo ""
echo "╔════════════════════════════════════════════════╗"
echo "║             修復完成報告                       ║"
echo "╚════════════════════════════════════════════════╝"
echo ""

kubectl get pods --all-namespaces -o wide | grep -E "default|kube-flannel" | grep -v "kube-system"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "服務訪問地址："
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  API:              http://test6.test/api/products"
echo "  Kong Admin:       http://192.168.10.10:8003"
echo "  Kong Proxy:       http://192.168.10.10:30000"
echo "  K8s Dashboard:    https://192.168.10.10:9443"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo -e "${GREEN}✓ 所有修復步驟已完成！${NC}"
echo ""
