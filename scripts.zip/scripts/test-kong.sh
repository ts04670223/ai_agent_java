#!/bin/bash

echo "========================================"
echo "Kong 配置檢查與測試"
echo "========================================"

# 顏色定義
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 檢查函數
check_service() {
    local name=$1
    local port=$2
    
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:$port > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC} $name (port $port) 運行正常"
        return 0
    else
        echo -e "${RED}✗${NC} $name (port $port) 無法連線"
        return 1
    fi
}

echo ""
echo "1. 檢查 Kong 服務狀態..."
echo "----------------------------------------"

# 檢查 Kong Proxy
if curl -s -o /dev/null -w "%{http_code}" http://localhost:8000 | grep -q "404"; then
    echo -e "${GREEN}✓${NC} Kong Proxy (port 8000) 運行中"
else
    echo -e "${RED}✗${NC} Kong Proxy (port 8000) 未運行"
fi

# 檢查 Kong Admin API
if curl -s http://localhost:8003 > /dev/null 2>&1; then
    echo -e "${GREEN}✓${NC} Kong Admin API (port 8003) 運行中"
    KONG_VERSION=$(curl -s http://localhost:8003 | grep -o '"version":"[^"]*"' | cut -d'"' -f4)
    echo "   Kong 版本: $KONG_VERSION"
else
    echo -e "${RED}✗${NC} Kong Admin API (port 8003) 未運行"
    echo -e "${YELLOW}提示: 請確認 Kong 是否已啟動${NC}"
    exit 1
fi

# 檢查 Kong Admin GUI
if curl -s -o /dev/null -w "%{http_code}" http://localhost:8002 | grep -q "200"; then
    echo -e "${GREEN}✓${NC} Kong Admin GUI (port 8002) 可訪問"
    echo "   訪問: http://192.168.10.10:8002"
else
    echo -e "${YELLOW}⚠${NC} Kong Admin GUI (port 8002) 可能未啟用"
fi

echo ""
echo "2. 檢查現有的 Kong 配置..."
echo "----------------------------------------"

# 列出所有服務
echo "Services:"
SERVICES=$(curl -s http://localhost:8003/services | grep -o '"name":"[^"]*"' | cut -d'"' -f4)
if [ -z "$SERVICES" ]; then
    echo -e "${YELLOW}  未找到任何服務${NC}"
else
    echo "$SERVICES" | while read -r service; do
        echo -e "  ${GREEN}→${NC} $service"
    done
fi

echo ""
echo "Routes:"
ROUTES=$(curl -s http://localhost:8003/routes | grep -o '"name":"[^"]*"' | cut -d'"' -f4)
if [ -z "$ROUTES" ]; then
    echo -e "${YELLOW}  未找到任何路由${NC}"
else
    echo "$ROUTES" | while read -r route; do
        echo -e "  ${GREEN}→${NC} $route"
    done
fi

echo ""
echo "Plugins:"
PLUGINS=$(curl -s http://localhost:8003/plugins | grep -o '"name":"[^"]*"' | cut -d'"' -f4)
if [ -z "$PLUGINS" ]; then
    echo "  未啟用任何插件"
else
    echo "$PLUGINS" | while read -r plugin; do
        echo -e "  ${GREEN}→${NC} $plugin"
    done
fi

echo ""
echo "3. 測試後端服務連線..."
echo "----------------------------------------"

# 測試 Spring Boot 應用
if curl -s http://localhost:8080/actuator/health > /dev/null 2>&1 || \
   curl -s http://localhost:8080 > /dev/null 2>&1; then
    echo -e "${GREEN}✓${NC} Spring Boot App (port 8080) 可連線"
else
    echo -e "${YELLOW}⚠${NC} Spring Boot App (port 8080) 未運行"
fi

# 測試前端
if curl -s http://localhost:3000 > /dev/null 2>&1; then
    echo -e "${GREEN}✓${NC} Frontend Vite (port 3000) 可連線"
else
    echo -e "${YELLOW}⚠${NC} Frontend Vite (port 3000) 未運行"
fi

echo ""
echo "4. 建立測試配置（test6.test）..."
echo "----------------------------------------"

# 檢查是否已存在 app-service
if curl -s http://localhost:8003/services/app-service > /dev/null 2>&1; then
    echo -e "${YELLOW}⚠${NC} Service 'app-service' 已存在，跳過建立"
else
    # 建立服務
    RESULT=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:8003/services \
        --data "name=app-service" \
        --data "url=http://localhost:8080")
    
    if [ "$RESULT" = "201" ] || [ "$RESULT" = "200" ]; then
        echo -e "${GREEN}✓${NC} 成功建立 Service: app-service → http://localhost:8080"
    else
        echo -e "${RED}✗${NC} 建立 Service 失敗 (HTTP $RESULT)"
    fi
fi

# 檢查是否已存在 test6-route
if curl -s http://localhost:8003/routes/test6-route > /dev/null 2>&1; then
    echo -e "${YELLOW}⚠${NC} Route 'test6-route' 已存在，跳過建立"
else
    # 建立路由
    RESULT=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:8003/services/app-service/routes \
        --data "name=test6-route" \
        --data "hosts[]=test6.test" \
        --data "paths[]=/api")
    
    if [ "$RESULT" = "201" ] || [ "$RESULT" = "200" ]; then
        echo -e "${GREEN}✓${NC} 成功建立 Route: test6.test/api → app-service"
    else
        echo -e "${RED}✗${NC} 建立 Route 失敗 (HTTP $RESULT)"
    fi
fi

# 啟用 CORS 插件（如果尚未啟用）
CORS_EXISTS=$(curl -s http://localhost:8003/plugins | grep -c "cors")
if [ "$CORS_EXISTS" -gt 0 ]; then
    echo -e "${YELLOW}⚠${NC} CORS 插件已啟用"
else
    RESULT=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:8003/plugins \
        --data "name=cors" \
        --data "config.origins=*" \
        --data "config.methods=GET" \
        --data "config.methods=POST" \
        --data "config.methods=PUT" \
        --data "config.methods=DELETE" \
        --data "config.methods=OPTIONS")
    
    if [ "$RESULT" = "201" ] || [ "$RESULT" = "200" ]; then
        echo -e "${GREEN}✓${NC} 成功啟用 CORS 插件"
    else
        echo -e "${RED}✗${NC} 啟用 CORS 插件失敗 (HTTP $RESULT)"
    fi
fi

echo ""
echo "5. 測試 Kong 路由..."
echo "----------------------------------------"

# 測試透過 Kong 訪問（使用 Host header）
echo "測試: curl -H 'Host: test6.test' http://localhost:8000/api"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" -H "Host: test6.test" http://localhost:8000/api 2>&1)
if [ "$RESPONSE" = "200" ] || [ "$RESPONSE" = "404" ]; then
    echo -e "${GREEN}✓${NC} Kong 路由正常 (HTTP $RESPONSE)"
    echo "   → 請求成功轉發到後端"
else
    echo -e "${RED}✗${NC} Kong 路由失敗 (HTTP $RESPONSE)"
fi

# 測試直接訪問
echo ""
echo "測試: curl http://localhost:8000/"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/ 2>&1)
if [ "$RESPONSE" = "404" ]; then
    echo -e "${GREEN}✓${NC} Kong Proxy 正常回應 (HTTP 404 - 未配置預設路由)"
else
    echo -e "${YELLOW}⚠${NC} Kong Proxy 回應: HTTP $RESPONSE"
fi

echo ""
echo "========================================"
echo "測試完成！"
echo "========================================"
echo ""
echo "下一步："
echo "1. 在主機 hosts 檔案加入: 192.168.10.10 test6.test"
echo "2. 訪問 Kong Admin GUI: http://192.168.10.10:8002"
echo "3. 測試前端: http://test6.test"
echo "4. 測試 API: http://test6.test/api"
echo ""
echo "詳細配置查詢："
echo "  curl http://localhost:8003/services"
echo "  curl http://localhost:8003/routes"
echo "  curl http://localhost:8003/plugins"
echo "========================================"
